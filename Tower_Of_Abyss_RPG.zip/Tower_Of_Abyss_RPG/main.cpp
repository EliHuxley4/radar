#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>   // rand, srand, system
#include <ctime>     // time
#include <algorithm> // max, min
#include <sstream>   // stringstream
#include <conio.h>   // _getch()
#include <windows.h> // Windows API

using namespace std;

// 自定义 toString 函数，解决报错 'to_string was not declared'
template <typename T>
string toString(T value) {
    stringstream ss;
    ss << value;
    return ss.str();
}

class ConsoleHelper {
public:
    // 设置光标位置
    static void setCursorPosition(int x, int y) {
        COORD coord;
        coord.X = x;
        coord.Y = y;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    }

    // 设置颜色
    static void setColor(int colorCode) {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorCode);
    }

    // 隐藏光标
    static void hideCursor() {
        CONSOLE_CURSOR_INFO cursorInfo;
        GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
        cursorInfo.bVisible = FALSE;
        SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
    }

    // 清屏
    static void clear() {
        // 使用 Windows API 清屏防止闪烁，或者直接 system("cls")
        system("cls");
    }
};

// 游戏数据结构
// 物品类型
const int TYPE_WEAPON = 0;
const int TYPE_ARMOR = 1;
const int TYPE_POTION = 2;
const int TYPE_ARTIFACT = 3;

struct Item {
    string name;
    string desc;
    int type;
    int value;
    int power;

    // 构造函数
    Item(string n, string d, int t, int v, int p) {
        name = n; desc = d; type = t; value = v; power = p;
    }

    // 默认构造函数
    Item() {
        name = ""; desc = ""; type = 0; value = 0; power = 0;
    }

    string getTypeStr() {
        if (type == TYPE_WEAPON) return "武器";
        if (type == TYPE_ARMOR) return "防具";
        if (type == TYPE_POTION) return "药水";
        if (type == TYPE_ARTIFACT) return "神器";
        return "未知";
    }
};

// 角色类
class Creature {
protected:
    string name;
    int maxHp;
    int hp;
    int attack;
    int defense;
    int level;

public:
    Creature(string n, int mh, int a, int d, int l) {
        name = n; maxHp = mh; hp = mh; attack = a; defense = d; level = l;
    }

    virtual ~Creature() {}

    string getName() { return name; }
    int getHp() { return hp; }
    int getMaxHp() { return maxHp; }
    int getLvl() { return level; }

    bool isDead() { return hp <= 0; }

    virtual void takeDamage(int dmg) {
        int actualDmg = dmg - defense;
        if (actualDmg < 1) actualDmg = 1;
        hp -= actualDmg;
        if (hp < 0) hp = 0;
    }

    void heal(int amount) {
        hp += amount;
        if (hp > maxHp) hp = maxHp;
    }

    virtual int getAttackPower() { return attack; }
};

class Hero : public Creature {
private:
    int exp;
    int expNext;
    int gold;
    int mana;
    int maxMana;
    int jobClass;
    vector<Item> inventory;
    Item equippedWeapon;
    Item equippedArmor;

public:
    int x, y;

    Hero() : Creature("冒险者", 100, 10, 2, 1) {
        // 手动初始化
        equippedWeapon = Item("无", "", TYPE_WEAPON, 0, 0);
        equippedArmor = Item("布衣", "", TYPE_ARMOR, 0, 1);
        exp = 0;
        expNext = 100;
        gold = 100;
        mana = 50;
        maxMana = 50;
        x = 1; y = 1;
        jobClass = 1;
    }

    void initClass(int choice, string n) {
        name = n;
        jobClass = choice;
        if (jobClass == 1) { // 战士
            maxHp = 150; hp = 150;
            attack = 15; defense = 5;
            maxMana = 30; mana = 30;
        } else { // 法师
            maxHp = 90; hp = 90;
            attack = 25; defense = 2;
            maxMana = 100; mana = 100;
        }
    }

    int getAttackPower() {
        return attack + equippedWeapon.power;
    }

    int getTotalDefense() {
        return defense + equippedArmor.power;
    }

    void gainExp(int amount) {
        exp += amount;
        if (exp >= expNext) levelUp();
    }

    void levelUp() {
        level++;
        exp -= expNext;
        expNext = (int)(expNext * 1.5);

        if (jobClass == 1) {
            maxHp += 30; attack += 5; defense += 3; maxMana += 5;
        } else {
            maxHp += 15; attack += 8; defense += 1; maxMana += 20;
        }
        hp = maxHp;
        mana = maxMana;

        ConsoleHelper::setColor(14); // 黄色
        cout << "\n >>> 升级了！当前等级: " << level << " <<< \n";
        ConsoleHelper::setColor(7);
        system("pause");
    }

    int getGold() { return gold; }
    void addGold(int g) { gold += g; }
    int getMana() { return mana; }
    void useMana(int m) { mana -= m; if(mana < 0) mana = 0; }
    void restoreMana(int m) { mana += m; if(mana > maxMana) mana = maxMana; }
    int getJobClass() { return jobClass; }

    void addItem(Item item) {
        inventory.push_back(item);
    }

    void openInventory() {
        bool inInv = true;
        while(inInv) {
            ConsoleHelper::clear();
            cout << "=== 背包 (Gold: " << gold << ") ===" << endl;
            cout << "当前装备: [" << equippedWeapon.name << "] [" << equippedArmor.name << "]" << endl;
            cout << "-----------------------------" << endl;
            if (inventory.empty()) cout << "  (背包为空)" << endl;

            // 使用普通 for 循环替代 auto
            for (size_t i = 0; i < inventory.size(); ++i) {
                cout << (i + 1) << ". " << inventory[i].name
                     << " (" << inventory[i].getTypeStr() << ") "
                     << "效果:" << inventory[i].power << endl;
            }
            cout << "-----------------------------" << endl;
            cout << "[输入数字使用/装备] [0 返回]: ";

            int choice;
            if (!(cin >> choice)) {
                cin.clear(); cin.ignore(1000, '\n');
                continue;
            }

            if (choice == 0) inInv = false;
            else if (choice > 0 && choice <= (int)inventory.size()) {
                useItem(choice - 1);
                system("pause");
            }
        }
    }

    void useItem(int index) {
        Item item = inventory[index];
        if (item.type == TYPE_POTION) {
            heal(item.power);
            cout << "使用了 " << item.name << "，恢复了生命。" << endl;
            inventory.erase(inventory.begin() + index);
        } else if (item.type == TYPE_WEAPON) {
            if (equippedWeapon.power > 0) inventory.push_back(equippedWeapon);
            equippedWeapon = item;
            inventory.erase(inventory.begin() + index);
            cout << "装备了 " << item.name << endl;
        } else if (item.type == TYPE_ARMOR) {
            if (equippedArmor.power > 0) inventory.push_back(equippedArmor);
            equippedArmor = item;
            inventory.erase(inventory.begin() + index);
            cout << "装备了 " << item.name << endl;
        }
    }
};

// 地图系统
const int MAP_W = 40;
const int MAP_H = 15;
class Map {
private:
    char grid[MAP_H][MAP_W];
    int floor;

public:
    Map() { floor = 1; }

    void generate(int currentFloor) {
        floor = currentFloor;
        // 初始化
        for(int y=0; y<MAP_H; y++)
            for(int x=0; x<MAP_W; x++)
                grid[y][x] = '#';

        // 挖房间
        for(int y=1; y<MAP_H-1; y++)
            for(int x=1; x<MAP_W-1; x++)
                grid[y][x] = '.';

        // 障碍
        for(int i=0; i<40; i++) {
            grid[rand()%(MAP_H-2)+1][rand()%(MAP_W-2)+1] = '#';
        }

        spawn('E', 5 + floor);
        spawn('$', 2);
        spawn('H', 1);
        spawn('>', 1);
    }

    void spawn(char type, int count) {
        for(int i=0; i<count; i++) {
            int rx, ry;
            do {
                rx = rand()%(MAP_W-2)+1;
                ry = rand()%(MAP_H-2)+1;
            } while(grid[ry][rx] != '.');
            grid[ry][rx] = type;
        }
    }

    char getTile(int x, int y) { return grid[y][x]; }
    void setTile(int x, int y, char c) { grid[y][x] = c; }
    int getFloor() { return floor; }

    void draw(int playerX, int playerY) {
        ConsoleHelper::setCursorPosition(0, 0);
        ConsoleHelper::setColor(11); // 蓝色
        cout << "== 深渊之塔 - 第 " << floor << " 层 ==" << endl;

        for(int y=0; y<MAP_H; y++) {
            for(int x=0; x<MAP_W; x++) {
                if(x == playerX && y == playerY) {
                    ConsoleHelper::setColor(10); // 绿色玩家
                    cout << "@";
                } else {
                    char tile = grid[y][x];
                    if (tile == '#') ConsoleHelper::setColor(8);
                    else if (tile == '.') ConsoleHelper::setColor(7);
                    else if (tile == 'E') ConsoleHelper::setColor(12);
                    else if (tile == '$') ConsoleHelper::setColor(14);
                    else if (tile == 'H') ConsoleHelper::setColor(9);
                    else if (tile == '>') ConsoleHelper::setColor(13);
                    cout << tile;
                }
            }
            cout << endl;
        }
    }
};

// 游戏引擎
class Game {
private:
    Hero player;
    Map map;
    bool isRunning;
    vector<string> eventLog;

public:
    Game() {
        isRunning = true;
        ConsoleHelper::hideCursor();
        srand((unsigned int)time(0));
    }

    void log(string msg) {
        eventLog.insert(eventLog.begin(), msg);
        if (eventLog.size() > 5) eventLog.pop_back();
    }

    void mainMenu() {
        while(true) {
            ConsoleHelper::clear();
            ConsoleHelper::setColor(11);
            cout << "################################" << endl;
            cout << "#       深 渊 之 塔            #" << endl;
            cout << "#    Tower of Abyss (RPG)      #" << endl;
            cout << "################################" << endl;
            ConsoleHelper::setColor(7);
            cout << "1. 新游戏" << endl;
            cout << "2. 退出" << endl;
            cout << "选择: ";
            char c = _getch();
            if (c == '1') {
                createCharacter();
                startGame();
                break;
            } else if (c == '2') {
                exit(0);
            }
        }
    }

    void createCharacter() {
        ConsoleHelper::clear();
        cout << "输入你的名字: ";
        string name;
        cin >> name;
        cout << "选择职业:\n1. 战士 (高血量/物理)\n2. 法师 (高爆发/魔法)\n选择: ";
        int job;
        cin >> job;
        player.initClass(job, name);
        player.x = 1; player.y = 1;
        map.generate(1);
        log("欢迎来到深渊之塔，" + name + "!");
    }

    void startGame() {
        // 游戏开始前先清理一次屏幕，确保干净
        ConsoleHelper::clear();
        while (isRunning && !player.isDead()) {
            drawInterface();
            handleInput();
        }

        if (player.isDead()) {
            ConsoleHelper::clear();
            ConsoleHelper::setColor(12);
            cout << "\n\n   你 倒 下 了  \n\n";
            ConsoleHelper::setColor(7);
            system("pause");
        }
    }

    void drawInterface() {
        // 在绘制界面前，尝试移动光标到起始位置而不是每次都 clear
        // 但是如果残留严重，可以在 map.draw() 内部的第一行 ConsoleHelper::setCursorPosition(0, 0) 之前
        // 或者在这里调用一次 clear。为了性能通常只覆盖，但为了修复残影，我们在离开 battle 时做 full clear
        map.draw(player.x, player.y);

        ConsoleHelper::setColor(15);
        // 使用空格填充行末，确保覆盖旧字符
        cout << "----------------------------------------    " << endl;
        cout << player.getName() << " Lv." << player.getLvl()
             << "  HP: " << player.getHp() << "/" << player.getMaxHp()
             << "  MP: " << player.getMana() << "  G: " << player.getGold() << "      " << endl;
        cout << "操作: WASD移动, I背包, K技能            " << endl;
        cout << "----------------------------------------    " << endl;

        ConsoleHelper::setColor(7);
        // 同样，为日志行添加填充空格，防止短日志无法覆盖旧的长日志
        for(size_t i = 0; i < eventLog.size(); ++i) {
            string msg = eventLog[i];
            // 简单填充至一定长度
            while(msg.length() < 50) msg += " ";
            cout << " > " << msg << endl;
        }
        // 清除可能的额外残留行（如果日志变少）
        for(size_t i = eventLog.size(); i < 5; ++i) {
             cout << "                                                    " << endl;
        }
    }

    void handleInput() {
        char key = _getch();
        int nx = player.x;
        int ny = player.y;

        key = tolower(key);
        if (key == 'w') ny--;
        else if (key == 's') ny++;
        else if (key == 'a') nx--;
        else if (key == 'd') nx++;
        else if (key == 'i') player.openInventory();
        else if (key == 'k') openSkillMenu();

        char tile = map.getTile(nx, ny);
        if (tile == '#') {
            log("撞到了墙壁。");
        } else if (tile == 'E') {
            battle("深渊怪物", map.getFloor());
            // 战斗结束后必须清屏，因为 battle 改变了界面布局
            ConsoleHelper::clear();
            map.setTile(nx, ny, '.');
        } else if (tile == '$') {
            int goldFound = rand() % 50 + 20;
            player.addGold(goldFound);
            player.addItem(Item("神秘卷轴", "卖钱", TYPE_ARTIFACT, 50, 0));
            log("发现宝箱！获得 " + toString(goldFound) + " 金币。");
            map.setTile(nx, ny, '.');
        } else if (tile == 'H') {
            player.heal(50);
            player.restoreMana(50);
            log("沐浴在泉水中，身心得到了治愈。");
            map.setTile(nx, ny, '.');
        } else if (tile == '>') {
            log("进入下一层...");
            map.generate(map.getFloor() + 1);
            player.x = 1; player.y = 1;
            // 切换楼层也建议清屏
            ConsoleHelper::clear();
            return;
        } else {
            player.x = nx;
            player.y = ny;
        }
    }

    void battle(string enemyName, int difficulty) {
        ConsoleHelper::clear();
        int eHp = 30 + (difficulty * 15);
        int eAtk = 5 + (difficulty * 3);
        int eDef = difficulty;
        Creature enemy(enemyName, eHp, eAtk, eDef, difficulty);

        ConsoleHelper::setColor(12);
        cout << "!!! 遭遇敌人 !!!" << endl;
        ConsoleHelper::setColor(7);

        while (!enemy.isDead() && !player.isDead()) {
            // 在循环开始处移动光标回顶部，覆盖上一回合的文字，而不是每次都 clear
            // 这样可以减少闪烁。或者简单点，每次 clear
            ConsoleHelper::setCursorPosition(0, 0);

            ConsoleHelper::setColor(12);
            cout << "!!! 遭遇敌人 !!!" << endl;
            ConsoleHelper::setColor(7);

            cout << "\n----------------------------    " << endl;
            cout << "敌: HP " << enemy.getHp() << "  (Atk:" << eAtk << ")      " << endl;
            cout << "我: HP " << player.getHp() << "  MP " << player.getMana() << "       " << endl;
            cout << "1. 攻击  2. 技能  3. 逃跑       " << endl;
            cout << "指令: ";

            // 清除之前的输入残留
            cout << "   \b\b\b";

            char act = _getch();

            int pDmg = 0;
            bool turnEnd = true;

            // 增加一些空白覆盖，防止上一次的战斗信息（如暴击）残留
            cout << "\n                                            \n";
            cout << "                                            \n";
            ConsoleHelper::setCursorPosition(0, 7); // 回到指令下方输出战斗日志

            if (act == '1') {
                pDmg = player.getAttackPower();
                cout << "\n你发起了攻击！                  " << endl;
            } else if (act == '2') {
                pDmg = useSkillInBattle();
                if (pDmg == -1) turnEnd = false;
            } else if (act == '3') {
                if (rand()%100 < 40) {
                    log("你逃跑了...");
                    return;
                }
                cout << "\n逃跑失败！                      " << endl;
            }

            if (turnEnd) {
                if (pDmg > 0) {
                    if (rand() % 100 < 15) {
                        pDmg = (int)(pDmg * 1.5);
                        cout << "暴击！！！ ";
                    }
                    enemy.takeDamage(pDmg);
                    cout << "造成 " << pDmg - eDef << " 点伤害。      " << endl;
                }

                if (!enemy.isDead()) {
                    player.takeDamage(eAtk);
                    cout << "受到 " << eAtk - player.getTotalDefense() << " 点伤害。      " << endl;
                }
            }
            // 清除可能的残留行
            cout << "                                            " << endl;
        }

        ConsoleHelper::clear(); // 战斗结束，先清屏

        if (!player.isDead()) {
            cout << "\n战斗胜利！" << endl;
            int expGain = 20 * difficulty;
            int goldGain = 15 * difficulty;
            player.gainExp(expGain);
            player.addGold(goldGain);
            log("击败敌人，获得 Exp:" + toString(expGain));

            if (rand() % 3 == 0) dropLoot(difficulty);
            system("pause");
        }
    }

    int useSkillInBattle() {
        if (player.getJobClass() == 1) {
            cout << "\n[战士技能] 1.重击(MP10) 2.返回: ";
            char c = _getch();
            if (c == '1') {
                if (player.getMana() >= 10) {
                    player.useMana(10);
                    return player.getAttackPower() * 2;
                } else cout << "MP不足！" << endl;
            }
        } else {
            cout << "\n[法师技能] 1.火球(MP15) 2.治疗(MP20) 3.返回: ";
            char c = _getch();
            if (c == '1') {
                if (player.getMana() >= 15) {
                    player.useMana(15);
                    return 40;
                } else cout << "MP不足！" << endl;
            } else if (c == '2') {
                if (player.getMana() >= 20) {
                    player.useMana(20);
                    player.heal(50);
                    cout << "恢复了50点生命。" << endl;
                    return 0;
                } else cout << "MP不足！" << endl;
            }
        }
        return -1;
    }

    void openSkillMenu() {
        ConsoleHelper::clear();
        cout << "=== 技能 ===" << endl;
        cout << "只能在战斗中使用技能。" << endl;
        system("pause");
    }

    void dropLoot(int difficulty) {
        int r = rand() % 100;
        if (r < 40) {
            player.addItem(Item("小回复药", "回复30HP", TYPE_POTION, 20, 30));
            log("获得: 小回复药");
        } else if (r < 70) {
            player.addItem(Item("铁剑", "攻击+", TYPE_WEAPON, 100, 5 + difficulty));
            log("获得: 铁剑");
        } else {
            player.addItem(Item("皮甲", "防御+", TYPE_ARMOR, 100, 2 + difficulty));
            log("获得: 皮甲");
        }
    }
};

// 主函数
int main() {
    system("chcp 65001");
    // 清屏以应用编码更改
    system("cls");
    Game game;
    game.mainMenu();
    return 0;
}
